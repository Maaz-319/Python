current_cashier = None
total_sales = 12484
