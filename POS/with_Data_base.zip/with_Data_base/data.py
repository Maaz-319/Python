current_cashier = None
